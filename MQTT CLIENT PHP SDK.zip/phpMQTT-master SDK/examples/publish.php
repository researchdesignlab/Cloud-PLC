<?php
error_reporting(0);
require("../phpMQTT.php");

$host = "postman.cloudmqtt.com";     // 
$port = your_port_number;            //Port number from cloud
$username = "your_username";         //username assigned from  
$password = "your_password";                   // set your password
$client_id = "phpMQTT-ai"; // make sure this is unique for connecting to sever - you could use uniqid()


$mqtt = new Bluerhinos\phpMQTT($host, $port, $client_id);

if ($mqtt->connect(true, NULL, $username, $password)) {
	$mqtt->publish("bluerhinos/phpMQTT/examples/publishtest", "How are you doing " . date("r"), 1);
	echo "success";
	//$mqtt->publish("bluerhinos/phpMQTT/examples/publishtest", "How are you doing", 2);
	$mqtt->close();
} else {
    echo "Time out!\n";
}
