<?php
error_reporting(0);
require("../phpMQTT.php");

$host = "postman.cloudmqtt.com";  // change if necessary
$port = 11139;                    // change if necessary
$username = "tbixettj";           // set your username
$password = "HvZ3_ff09s_5";       // set your password
$client_id = "phpMQTT-sa";        // make sure this is unique for connecting to sever - you could use uniqid()

$mqtt = new Bluerhinos\phpMQTT($host, $port, $client_id);

if(!$mqtt->connect(true, NULL, $username, $password)) {
	exit(1);
}

$topics['bluerhinos/phpMQTT/examples/publishtest'] = array("qos" => 1, "function" => "procmsg");
$mqtt->subscribe($topics, 1);

$start_time = time();
$done = 0;

while(!$done && !hasTimedout() && $mqtt->proc()){
		
}


$mqtt->close();

function procmsg($topic, $msg){
		global $done; 
		$done = 1;
		echo "Msg Recieved: " . date("r") . "\n";
		echo "Topic: {$topic}\n\n";
		echo "\t$msg\n\n";
}


function hasTimedout() {
	global $start_time; return (time() - $start_time > 20);//waits up to 10 sec 
} 