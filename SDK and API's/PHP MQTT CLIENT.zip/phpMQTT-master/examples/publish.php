<?php
error_reporting(0);
require("../phpMQTT.php");  //header file

$host = "your_host_name";     //Set the mqtt broker url. Ex: abc.cloudmqtt.com 

$port = port_number;     //Set the port number assigned from the cloud

$username = "your_username";  //Set the username assigned from the cloud 

$password = "your_password";  //set your password

$client_id = "phpMQTT-ai";    //client-id make sure this is unique for connecting to sever - you could use uniqid()

$topic = "bluerhinos/phpMQTT/examples/publishtest"; //The topic must be same in both publish and subscribe

$msg = "How are you doing "; //$msg is the message that has to sent using publish() function.

$mqtt = new Bluerhinos\phpMQTT($host, $port, $client_id); //$mqtt is a connection variable initialized with host, port and client-id

/*The below if condition has */
if ($mqtt->connect(true, NULL, $username, $password)) {
	/*The publish() function below sends the data*/
	$mqtt->publish($topic,  $msg. date("r"), 1);
	echo "success";
	$mqtt->close();
} else {
    echo "Time out!\n";
}
