<?php
error_reporting(0);
require("../phpMQTT.php");   //header file

$host = "your_host_name";     //Set the mqtt broker url. Ex: abc.cloudmqtt.com

$port = your_port_number;     //Set the port number assigned from the cloud

$username = "your_username";  //Set the username assigned from the cloud 

$password = "your_password";  //set your password

$client_id = "phpMQTT-ai";    //make sure this is unique for connecting to sever - you could use uniqid()

$topic = "bluerhinos/phpMQTT/examples/publishtest"; //The topic must be same in both publish and subscribe

$mqtt = new Bluerhinos\phpMQTT($host, $port, $client_id);

/*The below code checks for the mqtt connection with valid username and password*/
if(!$mqtt->connect(true, NULL, $username, $password)) {
	exit(1);
}

$topics[$topic] = array("qos" => 1, "function" => "procmsg");
$mqtt->subscribe($topics, 1);

$start_time = time();
$done = 0;

while(!$done && !hasTimedout() && $mqtt->proc()){
		
}


$mqtt->close();

/*The procmsg() is a callback function extracts the message sent from the publish*/
function procmsg($topic, $msg){
		global $done; 
		$done = 1;
		echo "Msg Recieved: " . date("r") . "\n";
		echo "Topic: {$topic}\n\n";
		echo "\t$msg\n\n";
}

/*The hasTimedout() function specifies timeout for successful subscription  */
function hasTimedout() {
	global $start_time; return (time() - $start_time > 20);//waits up to 20 sec 
} 