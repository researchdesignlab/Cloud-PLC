package com.example.mqttsdk;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.UnsupportedEncodingException;


public class MainActivity extends AppCompatActivity {

    IMqttToken token;
    MqttAndroidClient client;
    MqttMessage message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setUpMqttConnection();
    }

    public void setUpMqttConnection(){
        String clientId = MqttClient.generateClientId(); //Unique Client Id must be generate in order to push the message t
        String brokerUrl = "tcp://abc.mqtt.com:"; //the broker url of formattcp://abc.cloudmqtt.com:
        String portNunber= "port_number"; // the port number
        brokerUrl = brokerUrl+portNunber;
        client = new MqttAndroidClient(this.getApplicationContext(), brokerUrl,clientId); //MQTT client object that has connectio parameters

        try {
            IMqttToken token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    // Describes the successfull connections
                    Log.d("TAG", "onSuccess");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Something went wrong e.g. connection timeout or firewall problems
                    Log.d("TAG", "onFailure");

                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

        MqttConnectOptions options = new MqttConnectOptions();
        options.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1);
        options.setUserName("your_username"); //Set your username
        options.setPassword("your_password".toCharArray()); //Set your password
        try {
            token = client.connect(options);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    public void publish(){

        String topic = "fantasy"; // the topic must be same to publish and subscribe for mqtt
        String payload = "Hi this is a message from MQTT client"; //payload is the message that is published by the
        byte[] encodedPayload = new byte[0];
        try {
            encodedPayload = payload.getBytes("UTF-8");
            message = new MqttMessage(encodedPayload);
            message.setRetained(true);
            client.publish(topic, message); // the publish() function sends the data to the
        } catch (UnsupportedEncodingException | MqttException e) {
            e.printStackTrace();
        }
    }


    public void subscribeMethod(){
        final String topic = "fantasy"; //the topic must be same to publish and subscribe for mqtt
        int qos = 1;
        try {
            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {

                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    String payLoadMessage = new String(String.valueOf(message));
                    Toast.makeText(getApplicationContext(),payLoadMessage,Toast.LENGTH_LONG).show();
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {

                }
            });
            client.subscribe(topic, 0, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {

                }
                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {

                }
            });
        } catch (MqttException e) {
            displayToast(e.getMessage());
        }
    }

    public void invokePublish(View view){
        publish();
    }

    public void invokeSubscribe(View view){
        subscribeMethod();
    }

    public void displayToast(String message){
        Toast.makeText(getApplicationContext(),message,Toast.LENGTH_LONG).show();
    }

}
