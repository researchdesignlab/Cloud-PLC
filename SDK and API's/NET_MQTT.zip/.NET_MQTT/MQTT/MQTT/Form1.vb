﻿Imports System.Threading
Public Class Form1
    '*************************************************************************************

    Dim mosquittopath As String = "cd C:\mosquitto "
    Dim publishfilepath As String = "C:\mosquitto\publishmsg.txt"
    Dim subscribefilepath As String = "C:\mosquitto\submsg2.txt"

    '*************************************************************************************
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            TextBox1.Text = My.Settings.Host 'MQTT server Host name
            TextBox2.Text = My.Settings.Port 'MQTT server Port Number
            TextBox3.Text = My.Settings.User 'MQTT server Port Number
            TextBox4.Text = My.Settings.Password 'MQTT server Passsword
            TextBox5.Text = My.Settings.Topic 'MQTT server Publish Topic
            TextBox7.Text = My.Settings.subtopic 'MQTT server Subscribe Topic

            CheckBox1.Checked = False
            TextBox6.Visible = False
            Button4.Visible = False
            Label7.Visible = False
            ComboBox1.Visible = False
            Label10.Visible = False
            Label11.Visible = False
            Label12.Visible = False
            Label13.Visible = False
            Label14.Visible = False
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    Dim hostname As String = ""
    Dim port As String = ""
    Dim topic As String = ""
    Dim username As String = ""
    Dim password As String = ""
    Dim msg As String = ""
    Dim cafile As String = ""
    Dim scriptname As String = ""
    Dim scriptloc As String = ""
    Dim scriptloc1 = ""

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            My.Settings.Host = TextBox1.Text
            My.Settings.Port = TextBox2.Text
            My.Settings.User = TextBox3.Text
            My.Settings.Password = TextBox4.Text
            My.Settings.Topic = TextBox5.Text
            My.Settings.subtopic = TextBox7.Text

            For Each p As Process In Process.GetProcesses
                If p.ProcessName = "mosquitto_sub" Then
                    Try
                        p.Kill()
                        p.CloseMainWindow()
                    Catch ex As Exception
                        Continue For
                    End Try
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Dim read As System.IO.StreamReader
    Dim cnt As Integer = 0
    Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
        RichTextBox2.Text = ""
        Try
            If (cnt > 0) Then
                If thrdnm.IsAlive Then
                    CType(thrdnm, Thread).Abort()
                End If
            End If

            For Each p As Process In Process.GetProcesses
                If p.ProcessName = "mosquitto_sub" Then
                    Try
                        p.Kill()
                        p.CloseMainWindow()
                    Catch ex As Exception
                        Continue For
                    End Try
                End If
            Next
            hostname = Chr(34) + TextBox1.Text + Chr(34) 'MQTT server Host name
            port = Chr(34) + TextBox2.Text + Chr(34) 'MQTT server Port Number
            username = Chr(34) + TextBox3.Text + Chr(34) 'MQTT server Username
            password = Chr(34) + TextBox4.Text + Chr(34) 'MQTT server Passsword
            cafile = Chr(34) + TextBox6.Text + Chr(34) 'MQTT server Certificate File ( Required if SSL is Enabled)
            topic = Chr(34) + TextBox7.Text + Chr(34) 'MQTT server Subscribe Topic name
            Label13.Visible = True
            Label14.Visible = False
            If (CheckBox1.Checked = False) Then 'If SSL is not Enabled
                scriptloc1 = "/c cd\"
                scriptloc = mosquittopath
                scriptname = " mosquitto_pub -h " + hostname + " -p " + port + " -u " + username + " -P " + password + " -t " + topic + " -m " + Chr(34) + " " + Chr(34) + "> publishmsg.txt 2>&1"
                Dim process As System.Diagnostics.Process = New System.Diagnostics.Process()
                Dim startInfo As System.Diagnostics.ProcessStartInfo = New System.Diagnostics.ProcessStartInfo()
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                startInfo.FileName = "cmd.exe"
                startInfo.Arguments = scriptloc1 + "&" + scriptloc + "&" + scriptname
                process.StartInfo = startInfo
                process.Start()
                process.WaitForExit()

                Dim filepath2 = publishfilepath
                Dim line As String
                Using stream As New System.IO.FileStream(filepath2, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.ReadWrite), reader As New System.IO.StreamReader(stream)
                    While True
                        line = reader.ReadLine
                        If line Is Nothing Then
                            Exit While
                        Else
                            MsgBox(line)
                            Label13.Visible = False
                            Exit Sub
                        End If
                    End While
                End Using

                scriptloc1 = "/k cd\"
                scriptloc = mosquittopath
                scriptname = " mosquitto_sub -h " + hostname + " -p " + port + " -u " + username + " -P " + password + " -t " + topic + "> submsg2.txt 2>&1"
                Dim process2 As System.Diagnostics.Process = New System.Diagnostics.Process()
                Dim startInfo2 As System.Diagnostics.ProcessStartInfo = New System.Diagnostics.ProcessStartInfo()
                startInfo2.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                startInfo2.FileName = "cmd.exe"
                startInfo2.Arguments = scriptloc1 + "&" + scriptloc + "&" + scriptname
                process2.StartInfo = startInfo2
                process2.Start()

            Else  ' If SSL is Enabled

                scriptloc1 = "/c cd\"
                scriptloc = mosquittopath
                scriptname = " mosquitto_pub --cafile " + cafile + " --tls-version " + ComboBox1.SelectedItem + " -h " + hostname + " -p " + port + " -u " + username + " -P " + password + " -t " + topic + " -m " + Chr(34) + " " + Chr(34) + "> publishmsg.txt 2>&1"
                Dim process As System.Diagnostics.Process = New System.Diagnostics.Process()
                Dim startInfo As System.Diagnostics.ProcessStartInfo = New System.Diagnostics.ProcessStartInfo()
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                startInfo.FileName = "cmd.exe"
                startInfo.Arguments = scriptloc1 + "&" + scriptloc + "&" + scriptname
                process.StartInfo = startInfo
                process.Start()
                process.WaitForExit()

                Dim filepath2 = publishfilepath
                Dim line As String
                Using stream As New System.IO.FileStream(filepath2, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.ReadWrite), reader As New System.IO.StreamReader(stream)
                    While True
                        line = reader.ReadLine
                        If line Is Nothing Then
                            Exit While
                        Else
                            MsgBox(line)
                            Label13.Visible = False
                            Exit Sub
                        End If
                    End While
                End Using

                scriptloc1 = "/k cd\"
                scriptloc = mosquittopath
                scriptname = " mosquitto_sub --cafile " + cafile + " --tls-version " + ComboBox1.SelectedItem + " -h " + hostname + " -p " + port + " -u " + username + " -P " + password + " -t " + topic + "> submsg2.txt 2>&1"
                Dim process2 As System.Diagnostics.Process = New System.Diagnostics.Process()
                Dim startInfo2 As System.Diagnostics.ProcessStartInfo = New System.Diagnostics.ProcessStartInfo()
                startInfo2.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                startInfo2.FileName = "cmd.exe"
                startInfo2.Arguments = scriptloc1 + "&" + scriptloc + "&" + scriptname
                process2.StartInfo = startInfo2
                process2.Start()
            End If
            cnt = cnt + 1
            Dim thrd As New Thread(AddressOf displaysubmsg)
            thrdnm = thrd
            thrd.IsBackground = True
            thrd.Start()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Dim line As String = ""
    Dim thrdnm As Thread
    Sub displaysubmsg()
        Try


            Thread.Sleep(2000)
            Dim filepath3 = subscribefilepath

            Using stream As New System.IO.FileStream(filepath3, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.ReadWrite), reader As New System.IO.StreamReader(stream)
                While thrdnm.IsAlive
                    line = reader.ReadLine
                    ' MsgBox(line)
                    If line Is Nothing Then
                        Thread.Sleep(500)
                        If cnt > 1 Then
                            If Not thrdnm.IsAlive Then
                                Exit While
                            End If
                        End If
                        displaysub()
                    Else
                        displaymqttconnection()

                    End If
                End While
            End Using
        Catch ex As Exception
            '  MsgBox(ex.Message)
        End Try
    End Sub
#Region "displaymqttconnection"
    ''' <summary>
    ''' Method to display the data to and
    ''' from the port on the screen
    ''' </summary>
    ''' <remarks></remarks>
    <STAThread()>
    Private Sub displaymqttconnection()
        RichTextBox2.Invoke(New EventHandler(AddressOf Dodisplaymqttconnection))
    End Sub
#End Region


#Region "Dodisplaymqttconnection"
    Private Sub Dodisplaymqttconnection(ByVal sender As Object, ByVal e As EventArgs)
        ' MsgBox("Entered line")
        Label13.Visible = False
        Label14.Visible = False
        RichTextBox2.Text = line
    End Sub
#End Region

#Region "displaysub"
    ''' <summary>
    ''' Method to display the data to and
    ''' from the port on the screen
    ''' </summary>
    ''' <remarks></remarks>
    <STAThread()>
    Private Sub displaysub()
        Label13.Invoke(New EventHandler(AddressOf Dodisplaysub))
    End Sub
#End Region


#Region "Dodisplaysub"
    Private Sub Dodisplaysub(ByVal sender As Object, ByVal e As EventArgs)
        Label13.Visible = False
        Label14.Visible = True
    End Sub
#End Region
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Label11.Visible = False
            Label12.Visible = True

            hostname = Chr(34) + TextBox1.Text + Chr(34) 'MQTT server Host name
            port = Chr(34) + TextBox2.Text + Chr(34) 'MQTT server Port Number
            username = Chr(34) + TextBox3.Text + Chr(34) 'MQTT server Username
            password = Chr(34) + TextBox4.Text + Chr(34) 'MQTT server Password
            cafile = Chr(34) + TextBox6.Text + Chr(34) 'MQTT server subscribe certificate file ( Required if SSL is Enabled)
            topic = Chr(34) + TextBox5.Text + Chr(34) 'MQTT server publish topic name
            msg = Chr(34) + RichTextBox1.Text + Chr(34) 'Message to send
            If (CheckBox1.Checked = False) Then ' If SSL is not Enabled
                scriptloc1 = "/c cd\"
                scriptloc = mosquittopath
                scriptname = " mosquitto_pub -h " + hostname + " -p " + port + " -u " + username + " -P " + password + " -t " + topic + " -m " + msg + "> publishmsg.txt 2>&1"
                Dim process As System.Diagnostics.Process = New System.Diagnostics.Process()
                Dim startInfo As System.Diagnostics.ProcessStartInfo = New System.Diagnostics.ProcessStartInfo()
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                startInfo.FileName = "cmd.exe"
                startInfo.Arguments = scriptloc1 + "&" + scriptloc + "&" + scriptname
                process.StartInfo = startInfo
                process.Start()
                process.WaitForExit()
            Else  ' If SSL is Enabled
                scriptloc1 = "/c cd\"
                scriptloc = mosquittopath
                scriptname = " mosquitto_pub --cafile " + cafile + " --tls-version " + ComboBox1.SelectedItem + " -h " + hostname + " -p " + port + " -u " + username + " -P " + password + " -t " + topic + " -m " + msg + "> publishmsg.txt 2>&1"
                Dim process As System.Diagnostics.Process = New System.Diagnostics.Process()
                Dim startInfo As System.Diagnostics.ProcessStartInfo = New System.Diagnostics.ProcessStartInfo()
                startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                startInfo.FileName = "cmd.exe"
                startInfo.Arguments = scriptloc1 + "&" + scriptloc + "&" + scriptname
                process.StartInfo = startInfo
                process.Start()
                process.WaitForExit()
            End If
            Dim filepath2 = publishfilepath
            Dim line As String
            Using stream As New System.IO.FileStream(filepath2, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.ReadWrite), reader As New System.IO.StreamReader(stream)
                While True
                    line = reader.ReadLine
                    If line Is Nothing Then
                        Label11.Text = "Published"
                        Label11.Visible = True
                        Label12.Visible = False
                        Exit While
                    Else
                        MsgBox(line)
                        Label11.Text = "Error"
                        Label11.Visible = True
                        Label12.Visible = False

                        Exit While
                    End If
                End While
            End Using
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        OpenFileDialog1.InitialDirectory = "C:\"
        OpenFileDialog1.RestoreDirectory = True
        OpenFileDialog1.ShowDialog()
        If OpenFileDialog1.FileName.Length = 0 Then
        Else
            TextBox6.Text = System.IO.Path.GetFullPath(OpenFileDialog1.FileName)
        End If

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        Try
            If (CheckBox1.Checked = False) Then
                TextBox6.Visible = False
                Button4.Visible = False
                Label7.Visible = False
                ComboBox1.Visible = False
                Label10.Visible = False
            Else
                ComboBox1.SelectedIndex = 1
                TextBox6.Visible = True
                Button4.Visible = True
                Label7.Visible = True
                ComboBox1.Visible = True
                ComboBox1.SelectedIndex = 1
                Label10.Visible = True
            End If
        Catch ex As Exception

        End Try
    End Sub

    Dim filepath As String
    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        If Not CheckBox1.Checked Then
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
                MsgBox("All Fields are required..!")
            Else
                hostname = Chr(34) + TextBox1.Text + Chr(34)
                port = Chr(34) + TextBox2.Text + Chr(34)
                username = Chr(34) + TextBox3.Text + Chr(34)
                password = Chr(34) + TextBox4.Text + Chr(34)
            End If
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox6.Text = "" Then
                MsgBox("All Fields are required..!")
            Else
                hostname = Chr(34) + TextBox1.Text + Chr(34)
                port = Chr(34) + TextBox2.Text + Chr(34)
                username = Chr(34) + TextBox3.Text + Chr(34)
                password = Chr(34) + TextBox4.Text + Chr(34)
                cafile = Chr(34) + TextBox6.Text + Chr(34)
            End If
        End If
    End Sub


End Class

