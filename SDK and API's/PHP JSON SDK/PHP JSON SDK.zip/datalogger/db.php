<?php
$con=mysqli_connect("localhost","project18","0987abc","iotpi_db");

if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

?>