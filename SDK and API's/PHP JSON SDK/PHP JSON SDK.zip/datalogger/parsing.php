<?php
include 'db.php';
$data = trim(file_get_contents("php://input"));
//$data=$_GET["data"];
$query="insert into dataloggertestiing(data) values('$data')";
$status=mysqli_query($con,$query) or die(mysqli_error($con));
if($status){
 echo "value inserted";
}else{
    echo "value not inserted";
}
?>