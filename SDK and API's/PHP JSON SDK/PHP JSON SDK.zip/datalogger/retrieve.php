<?php
include 'db.php';

$query="select * from dataloggertestiing order by id desc limit 25";
$result=mysqli_query($con,$query) or die(mysqli_error($con)) ;
echo "<table border=\"1\" align=\"center\">";
echo "<tr><th width=\"80px\" height=\"35px\" align=\"center\" style=\"font-size: 20px\">S.No.</th><th width=\"120px\" height=\"35px\" align=\"center\" style=\"font-size: 20px\">Data</th></tr>";
while($row=mysqli_fetch_assoc($result)){
$id=$row["id"];
$data=$row["data"];
echo "<tr><td width=\"80px\"align=\"center\" height=\"35px\" style=\"font-size: 20px\">$id</td><td width=\"120px\" align=\"center\" height=\"35px\" style=\"font-size: 20px\">$data</td></tr>";
}
echo "</table>";

?>